Projeto Sistema de Vendas
Classes:
    NotaFiscal
    Cliente
    ItemNotaFiscal
    Produto

    